package com.example.a3d_printer_1

data class BeginPrint(val print_complete: String?=null, val beginPrint: String?=null, val fileNumLines: String?=null, val fileName: String?=null)
