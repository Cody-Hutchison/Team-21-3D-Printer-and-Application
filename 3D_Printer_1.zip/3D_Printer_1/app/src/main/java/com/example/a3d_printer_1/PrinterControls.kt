package com.example.a3d_printer_1

data class PrinterControls (val ext_temp: String?=null, val bed_temp: String?=null, val fan_speed: String?=null, val x_pos: String?=null, val y_pos: String?=null, val z_pos: String?=null)